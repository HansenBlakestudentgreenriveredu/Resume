<?php $form_complete = null; ?>
<h2>Contact</h2>
<form name = "contact" method = "POST" action = "process.php">
  
<div>
  <label for = "name">Name: </label><input type = "text" name = "name" placeholder = "Your Name"/>
</div>
  
<div>  
  <label for = "name">Email: </label><input type = "email" name = "email" placeholder = "Your Email"/>
</div>

<div>
  <label for = "name">Message: </label><input type = "textarea" name = "message" placeholder = "Your Message"/>
</div>
  
<div>
  <p>Reason for Contact: </p>
  <input type = "radio" name = "reason" id = "grading" value = "grading"/>
  <label for = "grading">Grading</label>
  <input type = "radio" name = "reason" id = "testing" value = "testing"/>
  <label for = "testing">Testing</label>
</div>

<div>
  <label for = "message">Message: </lable>
  <textarea name = "message"></textarea>
</div>

<div>
  <input type = "submit" name = "submit" value = "Submit"/>
</div>
<?php
$form_complete ?: true;
if($form_comple){
  foreach($_POST as $name => $value){
    if('submit' != $name){
      if(is_array($value)){
        $value = implode(', ', $value);
      }
      echo "<p><b>".unfirst($name)."</b> is $value.</p>";
    }
  }
}