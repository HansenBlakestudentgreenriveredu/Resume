<?php
$message = ' ';
foreach($_POST as $name => $value){
  if ('submit' != $name){
    if(is_array($value)){
      $value = implode(', ', $value);
    }
    $message.= ucfirst($name)."is $value.\n\n";
  }
  if(isset($POST['message'])&&
  empty(trim(&_POST['message']))){
  echo "<p class =\"alert\">Message required</p>";
  $form_complete = false;
  }
}
$to = "Blake<blakehansen2@hotmail.com>";
$submit = "email test: ".$_POST['reason'];
$form = $_POST['name'].'<'.$_POST['email'].'>';

$headers = 'From: '.$from."\r\n".
  'Reply-To: '.$form. "\r\n".
  'X-Mailer: PHP/'.phpversion();

if(mail($to, $submit, $message, $headers)){
  echo "<h3>Message sent!</h3>";
}
?>