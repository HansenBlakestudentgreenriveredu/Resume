   <!--Collect name, email and message from user. Message sent with PHP-->
<?php
 $to = "blakehansen2@hotmail.com";
 $subject = "HTML email";
 $message = "
 <html>
   <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>replit</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>PHP Email</title>
   </head>

  <body>
    <div class= "container-fluid">
     <div class = "row">
      <div class = "col-12">
       <nav>
        <a href ="index.html">Home</a>
        <a href ="resume.html">Resume</a>
        <a href ="projectSpotlight.html">Project-Spotlight</a>
        <a href ="contact.html">Contact</a>
       </nav>
      </div>
     </div>
    </div>

<?php $form_complete = null; ?>
<h2>Contact</h2>
<form name = "contact" method = "POST" action = "process.php">

<div>
  <label for = "name">Name: </label><input type = "text" name = "name" placeholder = "Your Name"/>
</div>

<div>  
  <label for = "name">Email: </label><input type = "email" name = "email" placeholder = "Your Email"/>
</div>

<div>
  <label for = "name">Message: </label><input type = "textarea" name = "message" placeholder = "Your Message"/>
</div>

<div>
  <p>Reason for Contact: </p>
  <input type = "radio" name = "reason" id = "grading" value = "grading"/>
  <label for = "grading">Grading</label>
  <input type = "radio" name = "reason" id = "testing" value = "testing"/>
  <label for = "testing">Testing</label>
</div>

<div>
  <label for = "message">Message: </lable>
  <textarea name = "message"></textarea>
</div>

<div>
  <input type = "submit" name = "submit" value = "Submit"/>
</div>
<?php
$form_complete ?: true;
if($form_comple){
  foreach($_POST as $name => $value){
    if('submit' != $name){
      if(is_array($value)){
        $value = implode(', ', $value);
      }
      echo "<p><b>".unfirst($name)."</b> is $value.</p>";
    }
  }
}
  </body>
  </html>
 ;"
 $headers = "MIME Version: 1.0"."/r/n";
 $headers.= "Content-type: text/html; charset=UTF-8"."/r/n";
 $headers.= "From: <blakehansen2@hotmail.com>."/r/n";
 mail($to,$subject,$message,$headers);
?>